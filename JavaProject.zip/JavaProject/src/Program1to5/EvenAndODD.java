package Program1to5;

import java.util.Scanner;

public class EvenAndODD {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = reader.nextInt();
        if(num%2==0)
        {
        	System.out.println("THIS IS AN EVEN NUMBER:");
        }
        else {
			System.out.println("THIS IS AN ODD NUMBER:");
		}

	}
}

