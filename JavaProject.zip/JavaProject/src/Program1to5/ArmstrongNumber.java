package Program1to5;

import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		Scanner sc= new Scanner (System.in);
		System.out.println("Enter the number");
		int n=sc.nextInt();
		int temp=n;
		int res=0;
		while(temp>0)
		{
			int s= temp%10;
			res= res+s*s*s;
			temp=temp%10;
		}
		if(res==n)
		{
			System.out.println("Given number is Armstrong");
		}
		else {
			System.out.println("Given number is not  Armstrong");
		}

	}

}
