package Program1to5;

import java.util.Scanner;

public class ReverseNumber {
  // we are creating reverse number using 3 ways
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		
		// using algorithm
	/*	int rev=0;
	/*	while(num!=0)
		{
			rev=rev*10+num%10;
			num=num/10;
		}*/
		
		
		// using StringBuffer class
	/*	StringBuffer sb= new StringBuffer(String.valueOf(num));
		 StringBuffer rev=sb.reverse();
       System.out.println("Reverse number:"+rev);
       */
		
		// using StringBuilder
		StringBuilder sb1= new StringBuilder ();
		sb1.append(num);
		StringBuilder rev= sb1.reverse();
		 System.out.println("Reverse number:"+rev);
		
		
		
       
       
	}

}
