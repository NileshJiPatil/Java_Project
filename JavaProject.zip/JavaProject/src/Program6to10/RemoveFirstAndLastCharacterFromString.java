package Program6to10;

public class RemoveFirstAndLastCharacterFromString {
	 public static String
	    removeFirstandLast(String str)
	    {
	 
	        // Removing first and last character
	        // of a string using substring() method
	        str = str.substring(1, str.length() - 1);
	 
	        // Return the modified string
	        return str;
	    }
	 
	    // Driver Code
	    public static void main(String args[])
	    {
	        // Given String str
	        String str = "Edubridge";
	 
	        // Print the modified string
	        System.out.print(
	            removeFirstandLast(str));
	    }
	

}
