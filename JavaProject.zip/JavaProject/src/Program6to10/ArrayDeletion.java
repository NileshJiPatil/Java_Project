package Program6to10;
import java.util.Arrays;

public class ArrayDeletion {
    public static void main(String[] args) {
        double[] array = {1, 3, 4, 5, 6, 7.9, 8, 9.9, 10};

        if (array.length >= 6) {
            // Create a new array with reduced size
            double[] newArray = new double[array.length - 2];
            
            // Copy elements up to the 4th element
            System.arraycopy(array, 0, newArray, 0, 4);
            
            // Copy elements from the 7th element onwards
            System.arraycopy(array, 6, newArray, 4, array.length - 6);

            System.out.println("Original array: " + Arrays.toString(array));
            System.out.println("Array after deletion: " + Arrays.toString(newArray));
        } else {
            System.out.println("Array length is too short to perform deletion.");
        }
    }
}
