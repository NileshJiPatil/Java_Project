package Program11to15;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
// exception handling with throw keyword
public class Test1 
{
    public static void main(String[] args) throws FileNotFoundException, ArrayIndexOutOfBoundsException, ArithmeticException
    {
        FileInputStream fis=new FileInputStream("");
    }
    void m1()
    {
        throw new ArithmeticException();
    }
}

